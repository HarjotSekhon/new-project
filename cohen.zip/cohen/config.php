<?php

/**
 * Configuration for database connection
 *
 */

// $host = "localhost";
// $username = "root";
// $password = "root";
// $dbname = "company";

// $baseDSN = "mysql:host=$host";
// $dsn = "mysql:host=$host;dbname=$dbname";
$dsn = "sqlite:C:\\xampp\\htdocs\\cohen\\db\\Cohen.sq3";
echo $dsn;




