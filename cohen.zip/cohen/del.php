<?php

if(isset( $_POST ['ID'] )) 
{
	
	try {
		
		require "config.php";
		require "common.php";

		$connection = new PDO ( $dsn );
		$connection->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		echo $dsn;
		// $location = $_POST ['location'];
		$ID = $_GET['ID'];
		$sql = "DELETE FROM Coverage WHERE ID = :ID";
		$statement = $connection->prepare ( $sql );
		$statement->bindParam (':ID', $ID);
		$statement->execute ();
			
	}  
		catch ( PDOException $error ) {
		echo "<h1>Error Creating coverage: </br></h1>";
		echo $sql. "<br>" . $error->getMessage ();
		exit ();
	}
   }
?>
 
<a href="index.php">Back to home</a>
